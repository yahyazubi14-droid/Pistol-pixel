import type { ReactNode } from "react";

export function PixelButton({
  children,
  onClick,
  variant = "default",
  disabled,
  className = "",
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "default" | "primary" | "danger" | "ghost";
  disabled?: boolean;
  className?: string;
  type?: "button" | "submit";
}) {
  const variants: Record<string, string> = {
    default: "bg-secondary text-secondary-foreground",
    primary: "bg-primary text-primary-foreground",
    danger: "bg-destructive text-destructive-foreground",
    ghost: "bg-muted text-muted-foreground",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`pixel-inset px-3 py-2 text-[9px] uppercase tracking-wide transition-none active:translate-y-[2px] disabled:opacity-40 ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Panel({
  title,
  onClose,
  children,
  footer,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-background/85 p-3">
      <div className="pixel-panel flex max-h-[86vh] w-full max-w-2xl flex-col">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-b-2 border-border bg-secondary px-3 py-2">
          <h2 className="truncate text-[10px] uppercase text-primary text-glow">{title}</h2>
          <button
            onClick={onClose}
            className="pixel-inset shrink-0 bg-destructive px-2 py-1 text-[9px] text-destructive-foreground"
          >
            X
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-3">{children}</div>
        {footer ? <div className="border-t-2 border-border p-2">{footer}</div> : null}
      </div>
    </div>
  );
}

export function Stat({ label, value, tone = "" }: { label: string; value: string; tone?: string }) {
  return (
    <div className="pixel-inset bg-popover px-2 py-1">
      <div className="text-[7px] text-muted-foreground">{label}</div>
      <div className={`text-[10px] ${tone}`}>{value}</div>
    </div>
  );
}
