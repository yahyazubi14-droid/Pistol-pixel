import { useEffect, useRef, useState, type ReactNode } from "react";
import { PlayerSprite, type Outfit } from "@/lib/game/sprites";

export const TILE = 16;
export const ROOM_W = 20; // tiles
export const ROOM_H = 12;
export const STAGE_W = ROOM_W * TILE;
export const STAGE_H = ROOM_H * TILE;

export type Zone = {
  id: string;
  label: string;
  x: number; // tile coords
  y: number;
  w: number;
  h: number;
};

type Props = {
  zones: Zone[];
  decor?: ReactNode;
  floorTint?: string;
  onAction: (zoneId: string) => void;
  spawn?: { x: number; y: number };
  moveRef: React.RefObject<{ x: number; y: number }>;
  outfit?: Outfit | undefined;
  actionSignal: number;
};

const SPEED = 1.4;

export function Room({ zones, decor, floorTint, onAction, spawn, moveRef, actionSignal, outfit }: Props) {
  const [pos, setPos] = useState(() => ({
    x: (spawn?.x ?? 3) * TILE,
    y: (spawn?.y ?? 8) * TILE,
  }));
  const posRef = useRef(pos);
  const keys = useRef<Record<string, boolean>>({});
  const [step, setStep] = useState(0);
  const [scale, setScale] = useState(2);
  const wrapRef = useRef<HTMLDivElement>(null);

  // Responsive integer-ish scaling of the pixel stage
  useEffect(() => {
    const fit = () => {
      const w = wrapRef.current?.clientWidth ?? STAGE_W;
      setScale(Math.max(1.2, Math.min(w / STAGE_W, 3.2)));
    };
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) e.preventDefault();
      keys.current[e.key.toLowerCase()] = true;
    };
    const up = (e: KeyboardEvent) => {
      keys.current[e.key.toLowerCase()] = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useEffect(() => {
    let raf = 0;
    let frame = 0;
    const tick = () => {
      const k = keys.current;
      const j = moveRef.current ?? { x: 0, y: 0 };
      let dx = (k["arrowright"] || k["d"] ? 1 : 0) - (k["arrowleft"] || k["a"] ? 1 : 0) + j.x;
      let dy = (k["arrowdown"] || k["s"] ? 1 : 0) - (k["arrowup"] || k["w"] ? 1 : 0) + j.y;
      const len = Math.hypot(dx, dy);
      if (len > 0) {
        dx = (dx / len) * SPEED;
        dy = (dy / len) * SPEED;
        const next = {
          x: Math.min(STAGE_W - TILE - 4, Math.max(4, posRef.current.x + dx)),
          y: Math.min(STAGE_H - TILE - 4, Math.max(2 * TILE, posRef.current.y + dy)),
        };
        posRef.current = next;
        setPos(next);
        frame += 1;
        if (frame % 8 === 0) setStep((s) => (s === 0 ? 1 : 0));
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [moveRef]);

  const active = zones.find((z) => {
    const cx = pos.x + TILE / 2;
    const cy = pos.y + TILE;
    return (
      cx >= z.x * TILE - 6 &&
      cx <= (z.x + z.w) * TILE + 6 &&
      cy >= z.y * TILE - 6 &&
      cy <= (z.y + z.h) * TILE + 10
    );
  });

  const activeId = active?.id;
  const lastSignal = useRef(actionSignal);
  useEffect(() => {
    if (actionSignal !== lastSignal.current) {
      lastSignal.current = actionSignal;
      if (activeId) onAction(activeId);
    }
  }, [actionSignal, activeId, onAction]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.key === "Enter" || e.key === " " || e.key.toLowerCase() === "e") && activeId) {
        e.preventDefault();
        onAction(activeId);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeId, onAction]);

  return (
    <div ref={wrapRef} className="w-full overflow-hidden">
      <div
        className="relative mx-auto"
        style={{ width: STAGE_W * scale, height: STAGE_H * scale }}
      >
        <div
          className="absolute left-0 top-0 origin-top-left"
          style={{ width: STAGE_W, height: STAGE_H, transform: `scale(${scale})` }}
        >
          {/* floor */}
          <div
            className="absolute inset-0"
            style={{
              backgroundColor: floorTint ?? "var(--color-floor)",
              backgroundImage:
                "linear-gradient(45deg, var(--color-floor-alt) 25%, transparent 25%, transparent 75%, var(--color-floor-alt) 75%)",
              backgroundSize: `${TILE * 2}px ${TILE * 2}px`,
            }}
          />
          {/* back wall */}
          <div
            className="absolute left-0 top-0 w-full"
            style={{
              height: 2 * TILE,
              backgroundColor: "var(--color-wall)",
              boxShadow: "inset 0 -3px 0 0 rgba(0,0,0,.45)",
            }}
          />
          {decor}
          {zones.map((z) => (
            <div
              key={z.id}
              className="absolute"
              style={{
                left: z.x * TILE,
                top: z.y * TILE,
                width: z.w * TILE,
                height: z.h * TILE,
                outline: z.id === activeId ? "2px solid var(--color-accent)" : "none",
              }}
            />
          ))}
          <div
            className="absolute"
            style={{ left: pos.x - 8, top: pos.y - 26, transform: "scale(1)" }}
          >
            <PlayerSprite scale={2} step={step} outfit={outfit} />
          </div>
          {active ? (
            <div
              className="absolute whitespace-nowrap px-1 text-accent"
              style={{ left: pos.x - 24, top: pos.y - 44, fontSize: 6 }}
            >
              <span className="blink">▲ {active.label}</span>
            </div>
          ) : null}
        </div>
        <div className="scanlines-overlay pointer-events-none absolute inset-0" />
      </div>
    </div>
  );
}
