import { useRef } from "react";

type Props = {
  moveRef: React.RefObject<{ x: number; y: number }>;
  onAction: () => void;
  onMap: () => void;
};

const dirs = [
  { key: "up", label: "▲", x: 0, y: -1, cls: "col-start-2 row-start-1" },
  { key: "left", label: "◀", x: -1, y: 0, cls: "col-start-1 row-start-2" },
  { key: "right", label: "▶", x: 1, y: 0, cls: "col-start-3 row-start-2" },
  { key: "down", label: "▼", x: 0, y: 1, cls: "col-start-2 row-start-3" },
];

export function TouchControls({ moveRef, onAction, onMap }: Props) {
  const held = useRef<Record<string, boolean>>({});

  const apply = () => {
    let x = 0;
    let y = 0;
    if (held.current['left']) x -= 1;
    if (held.current['right']) x += 1;
    if (held.current['up']) y -= 1;
    if (held.current['down']) y += 1;
    moveRef.current = { x, y };
  };

  const press = (key: string, on: boolean) => {
    held.current[key] = on;
    apply();
  };

  return (
    <div className="flex select-none items-end justify-between gap-4 px-2 pb-3 pt-2">
      <div className="grid grid-cols-3 grid-rows-3 gap-1">
        {dirs.map((d) => (
          <button
            key={d.key}
            className={`${d.cls} pixel-inset h-12 w-12 bg-secondary text-secondary-foreground active:bg-accent active:text-accent-foreground`}
            onPointerDown={(e) => {
              e.preventDefault();
              e.currentTarget.setPointerCapture(e.pointerId);
              press(d.key, true);
            }}
            onPointerUp={() => press(d.key, false)}
            onPointerCancel={() => press(d.key, false)}
            onPointerLeave={() => press(d.key, false)}
            aria-label={`Move ${d.key}`}
          >
            {d.label}
          </button>
        ))}
      </div>
      <div className="flex items-center gap-3">
        <button
          onClick={onMap}
          className="pixel-inset h-12 w-14 bg-secondary text-[8px] text-secondary-foreground active:bg-accent active:text-accent-foreground"
        >
          MAP
        </button>
        <button
          onClick={onAction}
          className="pixel-inset h-16 w-16 bg-primary text-primary-foreground active:bg-accent active:text-accent-foreground"
          aria-label="Action"
        >
          A
        </button>
      </div>
    </div>
  );
}
