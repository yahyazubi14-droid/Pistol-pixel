import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { money } from "@/lib/game/data";
import { Panel, PixelButton } from "../ui";

type Row = {
  id: string;
  display_name: string;
  net_worth: number;
  cars_owned: number;
};

export function LeaderboardPanel({ meId, onClose }: { meId: string | undefined; onClose: () => void }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [sort, setSort] = useState<"net_worth" | "cars_owned">("net_worth");

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, display_name, net_worth, cars_owned")
        .order(sort, { ascending: false })
        .limit(50);
      if (alive) setRows((data ?? []) as Row[]);
    };
    void load();
    const channel = supabase
      .channel("leaderboard")
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, () => void load())
      .subscribe();
    return () => {
      alive = false;
      supabase.removeChannel(channel);
    };
  }, [sort]);

  return (
    <Panel title="GLOBAL LEADERBOARD — LIVE" onClose={onClose}>
      <div className="mb-3 flex gap-1">
        <PixelButton variant={sort === "net_worth" ? "primary" : "default"} onClick={() => setSort("net_worth")}>
          NET CASH
        </PixelButton>
        <PixelButton variant={sort === "cars_owned" ? "primary" : "default"} onClick={() => setSort("cars_owned")}>
          CARS OWNED
        </PixelButton>
      </div>
      <div className="space-y-1">
        {rows.map((r, i) => (
          <div
            key={r.id}
            className={`pixel-inset grid grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-2 p-2 ${
              r.id === meId ? "bg-secondary" : "bg-popover"
            }`}
          >
            <span className={`text-[10px] ${i < 3 ? "text-gold" : "text-muted-foreground"}`}>
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="truncate text-[9px]">{r.display_name}</span>
            <span className="text-[9px] text-accent">
              {sort === "net_worth" ? money(r.net_worth) : `${r.cars_owned} CARS`}
            </span>
          </div>
        ))}
        {rows.length === 0 ? <p className="text-muted-foreground">NO PLAYERS YET.</p> : null}
      </div>
    </Panel>
  );
}
