import { CarSprite } from "@/lib/game/sprites";
import { carValue, condition, modelById, money, type CarRow } from "@/lib/game/data";
import { Panel, PixelButton } from "../ui";

type Props = {
  cars: CarRow[];
  onClose: () => void;
  onSell: (carId: string) => void;
  onUnlist: (carId: string) => void;
};

export function ShowroomPanel({ cars, onClose, onSell, onUnlist }: Props) {
  const lot = cars.filter((c) => c.listed);
  return (
    <Panel title="YOUR DEALERSHIP LOT" onClose={onClose}>
      {lot.length === 0 ? (
        <p className="text-muted-foreground">
          NOTHING ON THE LOT. FINISH A BUILD IN THE GARAGE AND MOVE IT HERE.
        </p>
      ) : (
        <div className="grid gap-2 sm:grid-cols-2">
          {lot.map((car) => {
            const m = modelById(car.model_id);
            return (
              <div key={car.id} className="pixel-inset flex items-center gap-2 bg-popover p-2">
                <CarSprite
                  scale={3}
                  state={{
                    shape: m.shape,
                    color: car.paint_color ?? m.color,
                    body: car.body,
                    wheels: car.wheels,
                    paint: car.paint,
                    engine: car.engine,
                  }}
                />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[9px] text-accent">{car.name}</div>
                  <div className="text-[7px] text-muted-foreground">COND {condition(car)}%</div>
                  <div className="mt-1 flex flex-wrap items-center justify-between gap-1">
                    <span className="text-[9px] text-gold">{money(carValue(car))}</span>
                    <div className="flex gap-1">
                      <PixelButton variant="ghost" onClick={() => onUnlist(car.id)}>
                        BACK
                      </PixelButton>
                      <PixelButton variant="primary" onClick={() => onSell(car.id)}>
                        SELL
                      </PixelButton>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Panel>
  );
}
