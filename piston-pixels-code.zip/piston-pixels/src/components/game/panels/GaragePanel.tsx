import { useState } from "react";
import { CarSprite } from "@/lib/game/sprites";
import {
  MAX_LEVEL,
  PAINT_COLORS,
  PARTS,
  carValue,
  condition,
  modelById,
  money,
  partCost,
  type CarRow,
  type PartKey,
} from "@/lib/game/data";
import { Panel, PixelButton } from "../ui";
import { useT } from "@/lib/i18n";

type Props = {
  cars: CarRow[];
  cash: number;
  onClose: () => void;
  onFit: (carId: string, part: PartKey, cost: number, color?: string) => void;
  onList: (carId: string, listed: boolean) => void;
};

export function GaragePanel({ cars, cash, onClose, onFit, onList }: Props) {
  const garage = cars.filter((c) => !c.listed);
  const [selectedId, setSelectedId] = useState(garage[0]?.id);
  const car = garage.find((c) => c.id === selectedId) ?? garage[0];
  const [color, setColor] = useState<string>("red");
  const { t } = useT();

  return (
    <Panel title={t("WORKSHOP — REPAIR BAY")} onClose={onClose}>
      {!car ? (
        <p className="text-muted-foreground">
          {t("GARAGE EMPTY. TELEPORT TO THE SCRAP MARKET AND BUY A PROJECT CAR.")}
        </p>
      ) : (
        <div className="space-y-3">
          <div className="flex flex-wrap gap-1">
            {garage.map((c) => (
              <PixelButton
                key={c.id}
                variant={c.id === car.id ? "primary" : "default"}
                onClick={() => setSelectedId(c.id)}
              >
                {c.name}
              </PixelButton>
            ))}
          </div>

          <div className="grid gap-3 sm:grid-cols-[auto_minmax(0,1fr)]">
            <div className="pixel-inset flex items-center justify-center bg-popover p-2">
              <CarSprite
                scale={5}
                state={{
                  shape: modelById(car.model_id).shape,
                  color: car.paint_color ?? modelById(car.model_id).color,
                  body: car.body,
                  wheels: car.wheels,
                  paint: car.paint,
                  engine: car.engine,
                }}
              />
            </div>
            <div className="min-w-0 space-y-2">
              <div className="text-[10px] text-primary">{car.name}</div>
              <div className="text-[8px] text-muted-foreground">
                {t("CONDITION")} {condition(car)}%
              </div>
              <div className="h-3 w-full bg-input">
                <div
                  className="h-3 bg-success"
                  style={{ width: `${condition(car)}%` }}
                />
              </div>
              <div className="text-[9px]">
                {t("VALUE")} <span className="text-gold">{money(carValue(car))}</span>
              </div>
              <PixelButton onClick={() => onList(car.id, true)} variant="primary">
                {t("MOVE TO SHOWROOM LOT")}
              </PixelButton>
            </div>
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            {PARTS.map((p) => {
              const lvl = car[p.key];
              const fitted = lvl >= MAX_LEVEL;
              const cost = partCost(car, p.key);
              return (
                <div key={p.key} className="pixel-inset bg-popover p-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[9px] text-accent">{t(p.label)}</span>
                    <span className="text-[8px] text-muted-foreground">
                      {t("LEVEL")} {lvl}/{MAX_LEVEL}
                    </span>
                  </div>
                  <div className="mt-1 flex gap-[2px]">
                    {Array.from({ length: MAX_LEVEL }, (_, i) => (
                      <div key={i} className={`h-2 flex-1 ${i < lvl ? "bg-success" : "bg-input"}`} />
                    ))}
                  </div>
                  <div className="text-[7px] text-muted-foreground">{p.blurb}</div>
                  {p.key === "paint" ? (
                    <div className="mt-1 flex flex-wrap gap-1">
                      {PAINT_COLORS.map((c) => (
                        <button
                          key={c}
                          onClick={() => setColor(c)}
                          aria-label={c}
                          className="h-5 w-5"
                          style={{
                            boxShadow:
                              c === color ? "0 0 0 2px var(--color-accent)" : "0 0 0 2px var(--color-border)",
                            backgroundColor:
                              c === "red"
                                ? "#f04c4c"
                                : c === "cyan"
                                  ? "#3ce0f0"
                                  : c === "lime"
                                    ? "#8cf03c"
                                    : c === "violet"
                                      ? "#b05cf0"
                                      : c === "amber"
                                        ? "#f0a93c"
                                        : c === "gold"
                                          ? "#f0d03c"
                                          : "#c8d0e0",
                          }}
                        />
                      ))}
                    </div>
                  ) : null}
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <span className="text-[9px] text-gold">{fitted ? "—" : money(cost)}</span>
                    {fitted ? (
                      <span className="text-[8px] text-success">{t("MAX LEVEL")} ✔</span>
                    ) : (
                      <PixelButton
                        disabled={cash < cost}
                        onClick={() => onFit(car.id, p.key, cost, p.key === "paint" ? color : undefined)}
                      >
                        {t("UPGRADE")} → {lvl + 1}
                      </PixelButton>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </Panel>
  );
}
