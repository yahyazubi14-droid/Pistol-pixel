import { useMemo } from "react";
import { CarSprite } from "@/lib/game/sprites";
import { SCRAP_MODELS, money } from "@/lib/game/data";
import { seeded } from "@/lib/game/clock";
import { Panel, PixelButton } from "../ui";

type Props = {
  cash: number;
  day: number;
  onClose: () => void;
  onBuy: (modelId: string, price: number) => void;
};

/** Stock rotates each in-game day, same for every player. */
export function MarketPanel({ cash, day, onClose, onBuy }: Props) {
  const stock = useMemo(() => {
    const rand = seeded(day + 17);
    return SCRAP_MODELS.map((m) => ({
      model: m,
      price: Math.round(m.scrapPrice * (0.85 + rand() * 0.45)),
      available: rand() > 0.2,
    })).filter((s) => s.available);
  }, [day]);

  return (
    <Panel title="SCRAP MARKETPLACE" onClose={onClose}>
      <p className="mb-3 text-[8px] text-muted-foreground">
        WRECKS ROTATE EVERY IN-GAME DAY. TOW ONE HOME AND REBUILD IT.
      </p>
      <div className="grid gap-2 sm:grid-cols-2">
        {stock.map(({ model, price }) => (
          <div key={model.id} className="pixel-inset flex items-center gap-2 bg-popover p-2">
            <CarSprite
              scale={3}
              state={{ shape: model.shape, color: model.color, body: false, wheels: false, paint: false, engine: false }}
            />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[9px] text-accent">{model.name}</div>
              <div className="text-[7px] text-muted-foreground">
                RESTORED VALUE {money(Math.round(model.baseValue * 1.18))}
              </div>
              <div className="mt-1 flex items-center justify-between gap-2">
                <span className="text-[9px] text-gold">{money(price)}</span>
                <PixelButton disabled={cash < price} onClick={() => onBuy(model.id, price)}>
                  BUY
                </PixelButton>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
}
