import { useEffect, useMemo, useRef, useState } from "react";
import { CarSprite } from "@/lib/game/sprites";
import { AUCTION_MODELS, money } from "@/lib/game/data";
import { REAL_MS_PER_DAY, formatDuration, getClock, seeded } from "@/lib/game/clock";
import { Panel, PixelButton } from "../ui";

const LOTS_PER_SUNDAY = 3;
const LOT_MS = REAL_MS_PER_DAY / LOTS_PER_SUNDAY;
const RIVALS = ["BIG SAL", "NEON NIA", "GEARHEAD 88", "MRS. TORQUE"];

type Props = {
  cash: number;
  onClose: () => void;
  onWin: (modelId: string, name: string, baseValue: number, price: number) => void;
  onMessage: (msg: string) => void;
};

export function AuctionPanel({ cash, onClose, onWin, onMessage }: Props) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, []);

  const clock = getClock(now);
  const msIntoDay = REAL_MS_PER_DAY - clock.msToNextDay;
  const lotIndex = Math.min(LOTS_PER_SUNDAY - 1, Math.floor(msIntoDay / LOT_MS));
  const msLeftInLot = LOT_MS - (msIntoDay % LOT_MS);

  const lots = useMemo(() => {
    const rand = seeded(clock.week * 31 + 7);
    return Array.from({ length: LOTS_PER_SUNDAY }, () => {
      const model = AUCTION_MODELS[Math.floor(rand() * AUCTION_MODELS.length)]!;
      const start = Math.round(model.baseValue * (0.3 + rand() * 0.15));
      const rivalMax = Math.round(model.baseValue * (0.55 + rand() * 0.35));
      return { model, start, rivalMax, rival: RIVALS[Math.floor(rand() * RIVALS.length)]! };
    });
  }, [clock.week]);

  const lot = lots[lotIndex]!;
  const [bid, setBid] = useState(lot.start);
  const [leader, setLeader] = useState<string>(lot.rival);
  const settled = useRef<string | null>(null);
  const lotKey = `${clock.week}-${lotIndex}`;

  // Reset state when the lot rolls over
  const prevKey = useRef(lotKey);
  useEffect(() => {
    if (prevKey.current !== lotKey) {
      prevKey.current = lotKey;
      setBid(lot.start);
      setLeader(lot.rival);
    }
  }, [lotKey, lot]);

  // Rival counter-bids
  useEffect(() => {
    if (leader !== "YOU") return;
    if (bid >= lot.rivalMax) return;
    const t = setTimeout(
      () => {
        const raise = Math.round(lot.model.baseValue * 0.04);
        setBid((b) => Math.min(lot.rivalMax, b + raise));
        setLeader(lot.rival);
      },
      1800 + Math.random() * 1600,
    );
    return () => clearTimeout(t);
  }, [bid, leader, lot]);

  // Hammer down
  useEffect(() => {
    if (msLeftInLot > 700) return;
    if (settled.current === lotKey) return;
    settled.current = lotKey;
    if (leader === "YOU") {
      onWin(lot.model.id, lot.model.name, lot.model.baseValue, bid);
      onMessage(`SOLD! YOU WON ${lot.model.name}`);
    }
  }, [msLeftInLot, leader, bid, lot, lotKey, onWin, onMessage]);

  if (!clock.isSunday) {
    return (
      <Panel title="AUCTION HOUSE — CLOSED" onClose={onClose}>
        <div className="space-y-2 text-center">
          <div className="text-[10px] text-destructive text-glow">DOORS LOCKED</div>
          <p className="text-[8px] text-muted-foreground">
            THE AUCTION ONLY RUNS ON IN-GAME SUNDAY.
          </p>
          <div className="text-[9px]">
            TODAY IS {clock.dayName} — NEXT SUNDAY IN{" "}
            <span className="text-accent">{formatDuration(clock.msToSunday)}</span>
          </div>
        </div>
      </Panel>
    );
  }

  const step = Math.round(lot.model.baseValue * 0.05);
  const nextBid = bid + step;

  return (
    <Panel title={`SUNDAY AUCTION — LOT ${lotIndex + 1}/${LOTS_PER_SUNDAY}`} onClose={onClose}>
      <div className="space-y-3">
        <div className="flex items-center justify-between text-[9px]">
          <span>WEEK {clock.week}</span>
          <span className="text-destructive">CLOSING {formatDuration(msLeftInLot)}</span>
        </div>
        <div className="pixel-inset flex flex-col items-center gap-2 bg-popover p-3">
          <CarSprite
            scale={6}
            state={{
              shape: lot.model.shape,
              color: lot.model.color,
              body: true,
              wheels: true,
              paint: true,
              engine: true,
            }}
          />
          <div className="text-[11px] text-primary text-glow">{lot.model.name}</div>
          <div className="text-[7px] text-muted-foreground">
            EXOTIC — BOOK VALUE {money(lot.model.baseValue)}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="pixel-inset bg-popover p-2">
            <div className="text-[7px] text-muted-foreground">CURRENT BID</div>
            <div className="text-[11px] text-gold">{money(bid)}</div>
          </div>
          <div className="pixel-inset bg-popover p-2">
            <div className="text-[7px] text-muted-foreground">HIGH BIDDER</div>
            <div className={`text-[10px] ${leader === "YOU" ? "text-success" : "text-accent"}`}>
              {leader}
            </div>
          </div>
        </div>
        <PixelButton
          variant="primary"
          className="w-full"
          disabled={leader === "YOU" || cash < nextBid}
          onClick={() => {
            setBid(nextBid);
            setLeader("YOU");
          }}
        >
          {cash < nextBid ? "NOT ENOUGH CASH" : `BID ${money(nextBid)}`}
        </PixelButton>
        <p className="text-[7px] text-muted-foreground">
          WIN THE LOT AND THE CAR ARRIVES FULLY RESTORED — SELL IT ON YOUR LOT FOR PROFIT.
        </p>
      </div>
    </Panel>
  );
}
