import { useT } from "@/lib/i18n";
import { Panel, PixelButton } from "./ui";

export type LocationId = "home" | "market" | "showroom" | "auction" | "leaderboard";

export const LOCATIONS: { id: LocationId; label: string; blurb: string; icon: string }[] = [
  { id: "home", label: "HOME GARAGE", blurb: "Your workshop & project cars", icon: "🏠" },
  { id: "market", label: "SCRAP MARKET", blurb: "Buy wrecks to restore", icon: "🔧" },
  { id: "showroom", label: "SHOWROOM", blurb: "Sell finished builds", icon: "🏷" },
  { id: "auction", label: "AUCTION HOUSE", blurb: "Sundays only — exotics", icon: "🔨" },
  { id: "leaderboard", label: "LEADERBOARD", blurb: "Live global rankings", icon: "🏆" },
];

export function TeleportMap({
  current,
  onTravel,
  onClose,
}: {
  current: LocationId;
  onTravel: (id: LocationId) => void;
  onClose: () => void;
}) {
  const { t } = useT();
  return (
    <Panel title="FAST TRAVEL TERMINAL" onClose={onClose}>
      <div className="grid gap-2 sm:grid-cols-2">
        {LOCATIONS.map((l) => (
          <button
            key={l.id}
            onClick={() => onTravel(l.id)}
            className={`pixel-inset flex items-center gap-2 p-3 text-left ${
              l.id === current ? "bg-secondary" : "bg-popover"
            }`}
          >
            <span className="text-lg">{l.icon}</span>
            <span className="min-w-0">
              <span className="block truncate text-[9px] text-accent">{t(l.label)}</span>
              <span className="block text-[7px] text-muted-foreground">{l.blurb}</span>
              {l.id === current ? (
                <span className="block text-[7px] text-success">YOU ARE HERE</span>
              ) : null}
            </span>
          </button>
        ))}
      </div>
      <div className="mt-3 flex justify-end">
        <PixelButton onClick={onClose}>CANCEL</PixelButton>
      </div>
    </Panel>
  );
}
