import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { MAX_LEVEL, carValue, type CarRow, type PartKey } from "@/lib/game/data";

export type Profile = {
  id: string;
  display_name: string;
  cash: number;
  cars_owned: number;
  net_worth: number;
  cars_sold: number;
  shirt_color: string;
  pants_color: string;
  hair_color: string;
};

export function useGame(userId: string | undefined) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [cars, setCars] = useState<CarRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!userId) return;
    const [{ data: p }, { data: c }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
      supabase.from("cars").select("*").eq("owner_id", userId).order("created_at"),
    ]);
    if (p) setProfile(p as Profile);
    setCars((c ?? []) as CarRow[]);
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    void load();
  }, [load]);

  /** Keep the public leaderboard stats in sync after every transaction. */
  const syncStats = useCallback(
    async (nextCash: number, nextCars: CarRow[], soldDelta = 0) => {
      if (!userId || !profile) return;
      const netWorth = Math.round(nextCash + nextCars.reduce((sum, car) => sum + carValue(car), 0));
      const patch = {
        cash: Math.round(nextCash),
        cars_owned: nextCars.length,
        net_worth: netWorth,
        cars_sold: profile.cars_sold + soldDelta,
        updated_at: new Date().toISOString(),
      };
      setProfile({ ...profile, ...patch });
      await supabase.from("profiles").update(patch).eq("id", userId);
    },
    [profile, userId],
  );

  const buyCar = useCallback(
    async (input: {
      model_id: string;
      name: string;
      rarity: string;
      base_value: number;
      price: number;
      restored?: boolean;
    }) => {
      if (!userId || !profile) return { ok: false, message: "NOT READY" };
      if (profile.cash < input.price) return { ok: false, message: "NOT ENOUGH CASH" };
      const { data, error } = await supabase
        .from("cars")
        .insert({
          owner_id: userId,
          model_id: input.model_id,
          name: input.name,
          rarity: input.rarity,
          base_value: input.base_value,
          engine: input.restored ? MAX_LEVEL : 0,
          body: input.restored ? MAX_LEVEL : 0,
          wheels: input.restored ? MAX_LEVEL : 0,
          paint: input.restored ? MAX_LEVEL : 0,
          paint_color: input.restored ? "gold" : null,
        })
        .select()
        .single();
      if (error || !data) return { ok: false, message: "PURCHASE FAILED" };
      const nextCars = [...cars, data as CarRow];
      setCars(nextCars);
      await syncStats(profile.cash - input.price, nextCars);
      return { ok: true, message: `BOUGHT ${input.name}` };
    },
    [cars, profile, syncStats, userId],
  );

  const fitPart = useCallback(
    async (carId: string, part: PartKey, cost: number, paintColor?: string) => {
      if (!profile) return { ok: false, message: "NOT READY" };
      if (profile.cash < cost) return { ok: false, message: "NOT ENOUGH CASH" };
      const car = cars.find((c) => c.id === carId);
      if (!car) return { ok: false, message: "NO CAR" };
      if (car[part] >= MAX_LEVEL) return { ok: false, message: "MAX LEVEL" };
      const patch: {
        engine?: number;
        body?: number;
        wheels?: number;
        paint?: number;
        paint_color?: string;
      } = { [part]: car[part] + 1 };
      if (part === "paint" && paintColor) patch["paint_color"] = paintColor;
      const { data, error } = await supabase
        .from("cars")
        .update(patch)
        .eq("id", carId)
        .select()
        .single();
      if (error || !data) return { ok: false, message: "FIT FAILED" };
      const nextCars = cars.map((c) => (c.id === carId ? (data as CarRow) : c));
      setCars(nextCars);
      await syncStats(profile.cash - cost, nextCars);
      return { ok: true, message: `${part.toUpperCase()} LEVEL ${car[part] + 1}` };
    },
    [cars, profile, syncStats],
  );

  const toggleListed = useCallback(
    async (carId: string, listed: boolean) => {
      const { data } = await supabase
        .from("cars")
        .update({ listed })
        .eq("id", carId)
        .select()
        .single();
      if (data) setCars((prev) => prev.map((c) => (c.id === carId ? (data as CarRow) : c)));
      return { ok: true, message: listed ? "MOVED TO LOT" : "BACK TO GARAGE" };
    },
    [],
  );

  const sellCar = useCallback(
    async (carId: string) => {
      if (!profile) return { ok: false, message: "NOT READY" };
      const car = cars.find((c) => c.id === carId);
      if (!car) return { ok: false, message: "NO CAR" };
      const price = carValue(car);
      await supabase.from("cars").delete().eq("id", carId);
      const nextCars = cars.filter((c) => c.id !== carId);
      setCars(nextCars);
      await syncStats(profile.cash + price, nextCars, 1);
      return { ok: true, message: `SOLD FOR ${price}` };
    },
    [cars, profile, syncStats],
  );

  const renamePlayer = useCallback(
    async (name: string) => {
      if (!userId || !profile) return;
      const clean = name.trim().slice(0, 14).toUpperCase() || "ROOKIE";
      setProfile({ ...profile, display_name: clean });
      await supabase.from("profiles").update({ display_name: clean }).eq("id", userId);
    },
    [profile, userId],
  );

  const saveOutfit = useCallback(
    async (o: { shirt_color: string; pants_color: string; hair_color: string }) => {
      if (!userId || !profile) return;
      setProfile({ ...profile, ...o });
      await supabase.from("profiles").update(o).eq("id", userId);
    },
    [profile, userId],
  );

  return { saveOutfit, profile, cars, loading, reload: load, buyCar, fitPart, toggleListed, sellCar, renamePlayer };
}
