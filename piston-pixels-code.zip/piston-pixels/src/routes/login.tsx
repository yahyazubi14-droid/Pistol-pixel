import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { PixelButton } from "@/components/game/ui";
import { CarSprite } from "@/lib/game/sprites";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log In — Piston Pixels" },
      {
        name: "description",
        content:
          "Restore wrecked cars, flip them from your pixel dealership, bid at the Sunday auction and climb the live leaderboard.",
      },
      { property: "og:title", content: "Piston Pixels — Pixel Car Dealership Game" },
      {
        property: "og:description",
        content:
          "Buy wrecks, fit engines, panels, wheels and paint, then sell for profit in a retro 16x16 pixel world.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SignIn,
});

function SignIn() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      if (session) void navigate({ to: "/" });
    });
    void supabase.auth.getSession().then(({ data }) => {
      if (data.session) void navigate({ to: "/" });
    });
    return () => sub.subscription.unsubscribe();
  }, [navigate]);

  const social = async (provider: "google" | "apple") => {
    setStatus(null);
    const result = await lovable.auth.signInWithOAuth(provider, {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setStatus("SIGN-IN FAILED. TRY AGAIN.");
      return;
    }
    if (result.redirected) return;
    void navigate({ to: "/" });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setStatus(null);
    if (mode === "signup") {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: window.location.origin,
          data: { display_name: name.toUpperCase().slice(0, 14) || "ROOKIE" },
        },
      });
      if (error) setStatus(error.message.toUpperCase());
      else if (!data.session) setStatus("CHECK YOUR EMAIL TO CONFIRM YOUR ACCOUNT");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setStatus(error.message.toUpperCase());
    }
    setBusy(false);
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 p-4">
      <div className="flex items-center gap-2">
        <CarSprite
          scale={4}
          state={{ shape: "super", color: "amber", body: true, wheels: true, paint: true, engine: true }}
        />
      </div>
      <h1 className="text-center text-[18px] text-primary text-glow sm:text-[24px]">PISTON PIXELS</h1>
      <p className="text-center text-[8px] text-muted-foreground">
        WRECK TO RICHES — CAR DEALERSHIP &amp; MECHANIC SIM
      </p>

      <div className="pixel-panel w-full max-w-sm p-4">
        <div className="mb-3 flex gap-1">
          <PixelButton
            className="flex-1"
            variant={mode === "signin" ? "primary" : "default"}
            onClick={() => setMode("signin")}
          >
            SIGN IN
          </PixelButton>
          <PixelButton
            className="flex-1"
            variant={mode === "signup" ? "primary" : "default"}
            onClick={() => setMode("signup")}
          >
            NEW GAME
          </PixelButton>
        </div>

        <form onSubmit={submit} className="space-y-2">
          {mode === "signup" ? (
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="PLAYER NAME"
              maxLength={14}
              className="pixel-inset w-full bg-input px-2 py-2 text-[9px] uppercase text-foreground outline-none placeholder:text-muted-foreground"
            />
          ) : null}
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="EMAIL"
            className="pixel-inset w-full bg-input px-2 py-2 text-[9px] text-foreground outline-none placeholder:text-muted-foreground"
          />
          <input
            type="password"
            required
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="PASSWORD"
            className="pixel-inset w-full bg-input px-2 py-2 text-[9px] text-foreground outline-none placeholder:text-muted-foreground"
          />
          <PixelButton type="submit" variant="primary" className="w-full" disabled={busy}>
            {busy ? "LOADING..." : mode === "signup" ? "START CAREER" : "CONTINUE"}
          </PixelButton>
        </form>

        <div className="my-3 text-center text-[7px] text-muted-foreground">— OR —</div>
        <div className="space-y-2">
          <PixelButton className="w-full" onClick={() => social("google")}>
            CONTINUE WITH GOOGLE
          </PixelButton>
          <PixelButton className="w-full" onClick={() => social("apple")}>
            CONTINUE WITH APPLE
          </PixelButton>
        </div>

        {status ? <p className="mt-3 text-[8px] text-accent">{status}</p> : null}
      </div>

      <p className="max-w-sm text-center text-[7px] leading-relaxed text-muted-foreground">
        PROGRESS AND LEADERBOARD RANK SAVE TO YOUR ACCOUNT.
      </p>
    </div>
  );
}
