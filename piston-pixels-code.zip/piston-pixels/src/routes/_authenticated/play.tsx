import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useGame } from "@/hooks/useGame";
import { Room, TILE, type Zone } from "@/components/game/Room";
import { TouchControls } from "@/components/game/TouchControls";
import { LOCATIONS, TeleportMap, type LocationId } from "@/components/game/TeleportMap";
import { GaragePanel } from "@/components/game/panels/GaragePanel";
import { MarketPanel } from "@/components/game/panels/MarketPanel";
import { ShowroomPanel } from "@/components/game/panels/ShowroomPanel";
import { AuctionPanel } from "@/components/game/panels/AuctionPanel";
import { LeaderboardPanel } from "@/components/game/panels/LeaderboardPanel";
import { PixelButton, Stat } from "@/components/game/ui";
import { useT } from "@/lib/i18n";
import { CarSprite } from "@/lib/game/sprites";
import { formatDuration, getClock } from "@/lib/game/clock";
import { carValue, modelById, money, type PartKey } from "@/lib/game/data";

export const Route = createFileRoute("/_authenticated/play")({
  head: () => ({
    meta: [
      { title: "Play Piston Pixels — Garage, Market, Auction" },
      {
        name: "description",
        content:
          "Walk your pixel garage, fit parts, flip restored cars from the showroom and bid at the Sunday auction house.",
      },
      { property: "og:title", content: "Play Piston Pixels" },
      {
        property: "og:description",
        content: "Restore wrecks, sell for profit and climb the live leaderboard.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Play,
});

const PAD: Zone = { id: "pad", label: "TELEPORT PAD", x: 16, y: 3, w: 3, h: 3 };

const ROOM_ZONES: Record<LocationId, Zone[]> = {
  home: [{ id: "garage", label: "REPAIR BAY", x: 2, y: 3, w: 5, h: 3 }, PAD],
  market: [{ id: "market", label: "SCRAP DEALER", x: 2, y: 3, w: 6, h: 3 }, PAD],
  showroom: [{ id: "showroom", label: "SALES DESK", x: 2, y: 3, w: 5, h: 3 }, PAD],
  auction: [{ id: "auction", label: "AUCTION PODIUM", x: 6, y: 3, w: 6, h: 3 }, PAD],
  leaderboard: [{ id: "leaderboard", label: "HALL OF FAME", x: 6, y: 3, w: 6, h: 3 }, PAD],
};

function Prop({
  x,
  y,
  w,
  h,
  color,
  label,
}: {
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  label?: string;
}) {
  return (
    <div
      className="absolute"
      style={{
        left: x * TILE,
        top: y * TILE,
        width: w * TILE,
        height: h * TILE,
        backgroundColor: color,
        boxShadow: "inset -3px -3px 0 rgba(0,0,0,.4), inset 3px 3px 0 rgba(255,255,255,.12)",
      }}
    >
      {label ? (
        <span
          className="absolute left-0 right-0 text-center text-foreground"
          style={{ top: 2, fontSize: 5 }}
        >
          {label}
        </span>
      ) : null}
    </div>
  );
}

function Play() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string>();
  useEffect(() => {
    void supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id));
  }, []);

  const game = useGame(userId);
  const { t } = useT();
  const [loc, setLoc] = useState<LocationId>("home");
  const [panel, setPanel] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const moveRef = useRef({ x: 0, y: 0 });
  const [actionSignal, setActionSignal] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const clock = getClock(now);

  const notify = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2600);
  }, []);

  // Give brand-new players their first wrecked project car.
  const seeded = useRef(false);
  useEffect(() => {
    if (!game.profile || game.loading || seeded.current) return;
    if (game.cars.length > 0 || game.profile.cars_sold > 0) {
      seeded.current = true;
      return;
    }
    seeded.current = true;
    void game
      .buyCar({
        model_id: "rustbucket",
        name: "RUSTBUCKET 82",
        rarity: "common",
        base_value: 4200,
        price: 0,
      })
      .then(() => notify("YOUR FIRST PROJECT CAR IS IN THE GARAGE"));
  }, [game, notify]);

  const openZone = useCallback((zoneId: string) => {
    setPanel(zoneId === "pad" ? "map" : zoneId);
  }, []);

  const exitToHome = () => void navigate({ to: "/" });

  const decor = useMemo(() => {
    const garageCars = game.cars.filter((c) => !c.listed).slice(0, 4);
    const lotCars = game.cars.filter((c) => c.listed).slice(0, 4);
    switch (loc) {
      case "home":
        return (
          <>
            <Prop x={2} y={3} w={5} h={3} color="var(--color-secondary)" label="TOOLS" />
            <Prop x={9} y={2} w={2} h={1} color="var(--color-muted)" />
            <Prop x={16} y={3} w={3} h={3} color="var(--color-accent)" label="PAD" />
            {garageCars.map((c, i) => {
              const m = modelById(c.model_id);
              return (
                <div key={c.id} className="absolute" style={{ left: 2 * TILE + i * 68, top: 7 * TILE }}>
                  <CarSprite
                    scale={2}
                    state={{
                      shape: m.shape,
                      color: c.paint_color ?? m.color,
                      body: c.body,
                      wheels: c.wheels,
                      paint: c.paint,
                      engine: c.engine,
                    }}
                  />
                </div>
              );
            })}
          </>
        );
      case "market":
        return (
          <>
            <Prop x={2} y={3} w={6} h={3} color="var(--color-secondary)" label="SCRAP" />
            <Prop x={10} y={3} w={2} h={2} color="var(--color-muted)" />
            <Prop x={16} y={3} w={3} h={3} color="var(--color-accent)" label="PAD" />
            <div className="absolute" style={{ left: 3 * TILE, top: 7 * TILE }}>
              <CarSprite
                scale={2}
                state={{ shape: "van", color: "rust", body: false, wheels: false, paint: false, engine: false }}
              />
            </div>
            <div className="absolute" style={{ left: 8 * TILE, top: 7 * TILE }}>
              <CarSprite
                scale={2}
                state={{ shape: "truck", color: "rust", body: false, wheels: false, paint: false, engine: false }}
              />
            </div>
          </>
        );
      case "showroom":
        return (
          <>
            <Prop x={2} y={3} w={5} h={3} color="var(--color-secondary)" label="DESK" />
            <Prop x={16} y={3} w={3} h={3} color="var(--color-accent)" label="PAD" />
            {lotCars.map((c, i) => {
              const m = modelById(c.model_id);
              return (
                <div key={c.id} className="absolute" style={{ left: 2 * TILE + i * 68, top: 7 * TILE }}>
                  <CarSprite
                    scale={2}
                    state={{
                      shape: m.shape,
                      color: c.paint_color ?? m.color,
                      body: c.body,
                      wheels: c.wheels,
                      paint: c.paint,
                      engine: c.engine,
                    }}
                  />
                </div>
              );
            })}
          </>
        );
      case "auction":
        return (
          <>
            <Prop x={6} y={3} w={6} h={3} color="var(--color-secondary)" label="PODIUM" />
            <Prop x={2} y={7} w={3} h={1} color="var(--color-muted)" />
            <Prop x={13} y={7} w={3} h={1} color="var(--color-muted)" />
            <Prop x={16} y={3} w={3} h={3} color="var(--color-accent)" label="PAD" />
            <div className="absolute" style={{ left: 7 * TILE, top: 6 * TILE }}>
              <CarSprite
                scale={2}
                state={{ shape: "super", color: "gold", body: true, wheels: true, paint: true, engine: true }}
              />
            </div>
          </>
        );
      case "leaderboard":
        return (
          <>
            <Prop x={6} y={3} w={6} h={3} color="var(--color-secondary)" label="RANKINGS" />
            <Prop x={16} y={3} w={3} h={3} color="var(--color-accent)" label="PAD" />
            <Prop x={3} y={6} w={1} h={3} color="var(--color-gold)" />
            <Prop x={15} y={6} w={1} h={3} color="var(--color-gold)" />
          </>
        );
    }
  }, [loc, game.cars]);

  const cash = game.profile?.cash ?? 0;
  const lotValue = game.cars.reduce((s, c) => s + carValue(c), 0);

  return (
    <div className="flex min-h-screen flex-col">
      {/* HUD */}
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-b-2 border-border bg-card px-3 py-2">
        <div className="flex min-w-0 flex-wrap items-center gap-2">
          <span className="truncate text-[10px] text-primary text-glow">
            {game.profile?.display_name ?? "..."}
          </span>
          <Stat label={t("CASH")} value={money(cash)} tone="text-gold" />
          <Stat label={t("CARS")} value={String(game.cars.length)} tone="text-accent" />
          <Stat label={t("NET")} value={money(cash + lotValue)} tone="text-success" />
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <Stat
            label={t(clock.isSunday ? "AUCTION DAY" : "NEXT SUNDAY")}
            value={clock.isSunday ? formatDuration(clock.msToNextDay) : formatDuration(clock.msToSunday)}
            tone={clock.isSunday ? "text-destructive" : ""}
          />
          <PixelButton variant="ghost" onClick={exitToHome}>
            {t("EXIT")}
          </PixelButton>
        </div>
      </header>

      <div className="flex items-center justify-between gap-2 bg-popover px-3 py-1">
        <span className="text-[8px] text-accent">
          {t(LOCATIONS.find((l) => l.id === loc)?.label ?? "")} — {t("WEEK")} {clock.week} {clock.dayName}
        </span>
        <span className="hidden text-[7px] text-muted-foreground sm:block">
          {t("ARROWS / WASD TO WALK · SPACE TO INTERACT")}
        </span>
      </div>

      <main className="flex flex-1 flex-col justify-between">
        <Room
          key={loc}
          zones={ROOM_ZONES[loc]}
          decor={decor}
          onAction={openZone}
          moveRef={moveRef}
          actionSignal={actionSignal}
          spawn={{ x: 9, y: 8 }}
          outfit={
            game.profile
              ? { shirt: game.profile.shirt_color, pants: game.profile.pants_color, hair: game.profile.hair_color }
              : undefined
          }
        />
        <TouchControls
          moveRef={moveRef}
          onAction={() => setActionSignal((s) => s + 1)}
          onMap={() => setPanel("map")}
        />
      </main>

      {toast ? (
        <div className="pointer-events-none fixed bottom-28 left-1/2 z-50 -translate-x-1/2 bg-card px-3 py-2 text-[9px] text-success pixel-inset">
          {toast}
        </div>
      ) : null}

      {panel === "map" ? (
        <TeleportMap
          current={loc}
          onClose={() => setPanel(null)}
          onTravel={(id) => {
            setLoc(id);
            setPanel(null);
            notify(`TELEPORTED TO ${LOCATIONS.find((l) => l.id === id)?.label}`);
          }}
        />
      ) : null}

      {panel === "garage" ? (
        <GaragePanel
          cars={game.cars}
          cash={cash}
          onClose={() => setPanel(null)}
          onFit={async (carId: string, part: PartKey, cost: number, color?: string) => {
            const r = await game.fitPart(carId, part, cost, color);
            notify(r.message);
          }}
          onList={async (carId, listed) => {
            const r = await game.toggleListed(carId, listed);
            notify(r.message);
          }}
        />
      ) : null}

      {panel === "market" ? (
        <MarketPanel
          cash={cash}
          day={clock.totalDays}
          onClose={() => setPanel(null)}
          onBuy={async (modelId, price) => {
            const m = modelById(modelId);
            const r = await game.buyCar({
              model_id: m.id,
              name: m.name,
              rarity: m.rarity,
              base_value: m.baseValue,
              price,
            });
            notify(r.message);
          }}
        />
      ) : null}

      {panel === "showroom" ? (
        <ShowroomPanel
          cars={game.cars}
          onClose={() => setPanel(null)}
          onSell={async (id) => {
            const r = await game.sellCar(id);
            notify(r.message);
          }}
          onUnlist={async (id) => {
            const r = await game.toggleListed(id, false);
            notify(r.message);
          }}
        />
      ) : null}

      {panel === "auction" ? (
        <AuctionPanel
          cash={cash}
          onClose={() => setPanel(null)}
          onMessage={notify}
          onWin={async (modelId, name, baseValue, price) => {
            await game.buyCar({
              model_id: modelId,
              name,
              rarity: "exotic",
              base_value: baseValue,
              price,
              restored: true,
            });
          }}
        />
      ) : null}

      {panel === "leaderboard" ? (
        <LeaderboardPanel meId={userId} onClose={() => setPanel(null)} />
      ) : null}
    </div>
  );
}
