import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useGame } from "@/hooks/useGame";
import { PixelButton } from "@/components/game/ui";
import { PlayerSprite } from "@/lib/game/sprites";
import { useT } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/customize")({
  head: () => ({
    meta: [
      { title: "Customize Your Mechanic — Piston Pixels" },
      { name: "description", content: "Pick shirt, pants and hair colors for your pixel mechanic." },
      { property: "og:title", content: "Customize Your Mechanic — Piston Pixels" },
      { property: "og:description", content: "Choose your mechanic's shirt, pants and hair colors." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Customize,
});

// Sprite palette colors (pixel art, rendered via box-shadow).
const SWATCHES = ["#f0a93c", "#f04c4c", "#3ce0f0", "#8cf03c", "#b05cf0", "#f0d03c", "#3c4a7c", "#22242e", "#e8e8f0", "#3a2a1c", "#c86a3c"];

type Key = "shirt_color" | "pants_color" | "hair_color";

function Customize() {
  const { t } = useT();
  const [userId, setUserId] = useState<string>();
  useEffect(() => {
    void supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id));
  }, []);
  const game = useGame(userId);
  const [o, setO] = useState<Record<Key, string> | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (game.profile && !o)
      setO({
        shirt_color: game.profile.shirt_color,
        pants_color: game.profile.pants_color,
        hair_color: game.profile.hair_color,
      });
  }, [game.profile, o]);

  const rows: { key: Key; label: string }[] = [
    { key: "shirt_color", label: "SHIRT" },
    { key: "pants_color", label: "PANTS" },
    { key: "hair_color", label: "HAIR" },
  ];

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 p-4">
      <h1 className="text-[16px] text-primary text-glow">{t("CUSTOMIZE")}</h1>
      <div className="pixel-panel w-full max-w-sm space-y-3 p-4">
        <div className="pixel-inset flex justify-center bg-popover py-3">
          <PlayerSprite
            scale={8}
            outfit={o ? { shirt: o.shirt_color, pants: o.pants_color, hair: o.hair_color } : undefined}
          />
        </div>
        {rows.map((r) => (
          <div key={r.key}>
            <div className="mb-1 text-[9px] text-accent">{t(r.label)}</div>
            <div className="flex flex-wrap gap-2">
              {SWATCHES.map((c) => (
                <button
                  key={c}
                  aria-label={`${r.label} ${c}`}
                  onClick={() => {
                    setSaved(false);
                    setO((prev) => (prev ? { ...prev, [r.key]: c } : prev));
                  }}
                  className="h-6 w-6"
                  style={{
                    backgroundColor: c,
                    boxShadow:
                      o?.[r.key] === c ? "0 0 0 3px var(--color-accent)" : "0 0 0 2px var(--color-border)",
                  }}
                />
              ))}
            </div>
          </div>
        ))}
        <PixelButton
          variant="primary"
          className="w-full"
          disabled={!o}
          onClick={async () => {
            if (!o) return;
            await game.saveOutfit(o);
            setSaved(true);
          }}
        >
          {saved ? `${t("SAVED")} ✔` : t("SAVE")}
        </PixelButton>
        <Link to="/" className="pixel-inset block bg-muted px-3 py-2 text-center text-[9px] text-muted-foreground">
          {t("BACK")}
        </Link>
      </div>
    </div>
  );
}
