import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PixelButton } from "@/components/game/ui";
import { CarSprite } from "@/lib/game/sprites";
import { useT } from "@/lib/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Piston Pixels — 16-bit Car Dealership & Mechanic Game" },
      {
        name: "description",
        content:
          "Restore wrecked cars, flip them from your pixel dealership, bid at the Sunday auction and climb the live leaderboard.",
      },
      { property: "og:title", content: "Piston Pixels — Pixel Car Dealership Game" },
      {
        property: "og:description",
        content: "Buy wrecks, upgrade engines, panels, wheels and paint, then sell for profit in a retro pixel world.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const { t } = useT();
  const [signedIn, setSignedIn] = useState<boolean | null>(null);

  useEffect(() => {
    void supabase.auth.getSession().then(({ data }) => setSignedIn(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSignedIn(!!s));
    return () => sub.subscription.unsubscribe();
  }, []);

  const btn = "pixel-inset block w-full px-3 py-3 text-center text-[10px] uppercase";

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 p-4">
      <CarSprite
        scale={4}
        state={{ shape: "super", color: "amber", body: true, wheels: true, paint: true, engine: true }}
      />
      <h1 className="text-center text-[18px] text-primary text-glow sm:text-[24px]">PISTON PIXELS</h1>
      <p className="text-center text-[8px] text-muted-foreground">
        {t("WRECK TO RICHES — CAR DEALERSHIP & MECHANIC SIM")}
      </p>

      <div className="pixel-panel w-full max-w-sm space-y-2 p-4">
        {signedIn === null ? (
          <p className="text-center text-[8px] text-muted-foreground">...</p>
        ) : signedIn ? (
          <>
            <Link to="/play" className={`${btn} bg-primary text-primary-foreground`}>
              ▶ {t("START GAME")}
            </Link>
            <Link to="/customize" className={`${btn} bg-secondary text-secondary-foreground`}>
              {t("CUSTOMIZE")}
            </Link>
            <Link to="/settings" className={`${btn} bg-secondary text-secondary-foreground`}>
              {t("SETTINGS")}
            </Link>
            <PixelButton variant="ghost" className="w-full" onClick={() => void supabase.auth.signOut()}>
              {t("SIGN OUT")}
            </PixelButton>
          </>
        ) : (
          <Link to="/login" className={`${btn} bg-primary text-primary-foreground`}>
            {t("LOG IN")}
          </Link>
        )}
      </div>
    </div>
  );
}
