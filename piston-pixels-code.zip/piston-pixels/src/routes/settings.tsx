import { createFileRoute, Link } from "@tanstack/react-router";
import { PixelButton } from "@/components/game/ui";
import { useT } from "@/lib/i18n";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Piston Pixels" },
      { name: "description", content: "Change the Piston Pixels game language between English and Arabic." },
      { property: "og:title", content: "Settings — Piston Pixels" },
      { property: "og:description", content: "Switch the game language between English and Arabic." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Settings,
});

function Settings() {
  const { t, lang, setLang } = useT();
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 p-4">
      <h1 className="text-[16px] text-primary text-glow">{t("SETTINGS")}</h1>
      <div className="pixel-panel w-full max-w-sm space-y-3 p-4">
        <div className="text-[9px] text-accent">{t("LANGUAGE")}</div>
        <div className="flex gap-2">
          <PixelButton className="flex-1" variant={lang === "en" ? "primary" : "default"} onClick={() => setLang("en")}>
            ENGLISH
          </PixelButton>
          <PixelButton className="flex-1" variant={lang === "ar" ? "primary" : "default"} onClick={() => setLang("ar")}>
            العربية
          </PixelButton>
        </div>
        <Link to="/" className="pixel-inset block bg-muted px-3 py-2 text-center text-[9px] text-muted-foreground">
          {t("BACK")}
        </Link>
      </div>
    </div>
  );
}
