/** In-game week: one in-game day lasts REAL_MS_PER_DAY of real time. */
export const REAL_MS_PER_DAY = 3 * 60 * 1000; // 3 real minutes = 1 in-game day
export const DAYS = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"] as const;
const EPOCH = Date.UTC(2026, 0, 5); // a Monday

export type GameClock = {
  totalDays: number;
  week: number;
  dayIndex: number;
  dayName: string;
  isSunday: boolean;
  /** ms until the current in-game day ends */
  msToNextDay: number;
  /** ms until the next Sunday starts (0 while it is Sunday) */
  msToSunday: number;
};

export function getClock(now: number = Date.now()): GameClock {
  const elapsed = Math.max(0, now - EPOCH);
  const totalDays = Math.floor(elapsed / REAL_MS_PER_DAY);
  const dayIndex = totalDays % 7;
  const msIntoDay = elapsed % REAL_MS_PER_DAY;
  const daysToSunday = (6 - dayIndex + 7) % 7;
  return {
    totalDays,
    week: Math.floor(totalDays / 7) + 1,
    dayIndex,
    dayName: DAYS[dayIndex]!,
    isSunday: dayIndex === 6,
    msToNextDay: REAL_MS_PER_DAY - msIntoDay,
    msToSunday: dayIndex === 6 ? 0 : daysToSunday * REAL_MS_PER_DAY - msIntoDay,
  };
}

export function formatDuration(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

/** Deterministic pseudo-random generator so every player sees the same auction. */
export function seeded(seed: number) {
  let s = seed * 9301 + 49297;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}
