export type Rarity = "common" | "rare" | "exotic";

export type CarModel = {
  id: string;
  name: string;
  rarity: Rarity;
  baseValue: number;
  scrapPrice: number;
  shape: "coupe" | "sedan" | "truck" | "van" | "super";
  color: string; // token-ish hue key used by the sprite palette
};

export const CAR_MODELS: CarModel[] = [
  { id: "rustbucket", name: "RUSTBUCKET 82", rarity: "common", baseValue: 4200, scrapPrice: 900, shape: "sedan", color: "rust" },
  { id: "hatchling", name: "HATCHLING GT", rarity: "common", baseValue: 5600, scrapPrice: 1300, shape: "coupe", color: "lime" },
  { id: "boxvan", name: "BOX VAN 500", rarity: "common", baseValue: 6400, scrapPrice: 1500, shape: "van", color: "cyan" },
  { id: "muleton", name: "MULE TON PICKUP", rarity: "common", baseValue: 7800, scrapPrice: 1900, shape: "truck", color: "amber" },
  { id: "cruiser", name: "CRUISER DELUXE", rarity: "common", baseValue: 9500, scrapPrice: 2400, shape: "sedan", color: "blue" },
  { id: "bolt", name: "BOLT COUPE", rarity: "rare", baseValue: 14000, scrapPrice: 3900, shape: "coupe", color: "red" },
  { id: "phantom", name: "PHANTOM TURBO", rarity: "rare", baseValue: 19000, scrapPrice: 5400, shape: "super", color: "violet" },
  // Auction-only exotics
  { id: "vipera", name: "VIPERA GX", rarity: "exotic", baseValue: 42000, scrapPrice: 0, shape: "super", color: "lime" },
  { id: "aurelia", name: "AURELIA 60S", rarity: "exotic", baseValue: 58000, scrapPrice: 0, shape: "coupe", color: "gold" },
  { id: "monolith", name: "MONOLITH V12", rarity: "exotic", baseValue: 75000, scrapPrice: 0, shape: "super", color: "silver" },
  { id: "gigatruck", name: "GIGA HAULER", rarity: "exotic", baseValue: 36000, scrapPrice: 0, shape: "truck", color: "cyan" },
];

export const modelById = (id: string) => CAR_MODELS.find((m) => m.id === id) ?? CAR_MODELS[0]!;

export const SCRAP_MODELS = CAR_MODELS.filter((m) => m.rarity !== "exotic");
export const AUCTION_MODELS = CAR_MODELS.filter((m) => m.rarity === "exotic");

export type PartKey = "engine" | "body" | "wheels" | "paint";

export const PARTS: { key: PartKey; label: string; blurb: string; costRatio: number }[] = [
  { key: "engine", label: "ENGINE", blurb: "Rebuilt block + turbo", costRatio: 0.18 },
  { key: "body", label: "BODY PANELS", blurb: "Straighten & weld", costRatio: 0.14 },
  { key: "wheels", label: "NEW WHEELS", blurb: "Fresh alloys + tires", costRatio: 0.1 },
  { key: "paint", label: "PAINT JOB", blurb: "Custom arcade finish", costRatio: 0.08 },
];

export const PAINT_COLORS = ["red", "cyan", "lime", "violet", "amber", "gold", "silver"] as const;

export type CarRow = {
  id: string;
  owner_id: string;
  model_id: string;
  name: string;
  rarity: string;
  base_value: number;
  engine: number;
  body: number;
  wheels: number;
  paint: number;
  paint_color: string | null;
  listed: boolean;
  created_at: string;
};

export const MAX_LEVEL = 5;

export const totalLevels = (car: Pick<CarRow, PartKey>) =>
  car.engine + car.body + car.wheels + car.paint;

/** 20 (wreck) .. 100 (all parts at max level) */
export const condition = (car: Pick<CarRow, PartKey>) => 20 + totalLevels(car) * 4;

/** Cost of the next level for a part; each level costs more than the last. */
export const partCost = (car: Pick<CarRow, "base_value" | PartKey>, key: PartKey) => {
  const ratio = PARTS.find((p) => p.key === key)!.costRatio;
  const next = Math.min(car[key] + 1, MAX_LEVEL);
  return Math.round((car.base_value * ratio * next) / 15);
};

/** Resale value rises with condition, with a bonus for a fully maxed build. */
export const carValue = (car: Pick<CarRow, PartKey | "base_value">) => {
  const c = condition(car);
  const bonus = c === 100 ? 1.18 : 1;
  return Math.round(car.base_value * (c / 100) * bonus);
};

export const money = (n: number) => "$" + Math.round(n).toLocaleString("en-US");
