/**
 * 16x16 pixel-art sprite renderer.
 * Sprite pixels are artwork data (like an image file), not theme colors.
 */

export const SPRITE_PALETTE: Record<string, string> = {
  rust: "#8a4b2a",
  lime: "#8cf03c",
  cyan: "#3ce0f0",
  amber: "#f0a93c",
  blue: "#3c7cf0",
  red: "#f04c4c",
  violet: "#b05cf0",
  gold: "#f0d03c",
  silver: "#c8d0e0",
  dull: "#6b6f86",
};

const shade = (hex: string) => {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.max(0, ((n >> 16) & 255) - 60);
  const g = Math.max(0, ((n >> 8) & 255) - 60);
  const b = Math.max(0, (n & 255) - 60);
  return `rgb(${r},${g},${b})`;
};

type Shape = "coupe" | "sedan" | "truck" | "van" | "super";

const SHAPES: Record<Shape, string[]> = {
  coupe: [
    "................",
    "................",
    "................",
    "................",
    ".....dbbbbd.....",
    "....dbwwwwbd....",
    "...dbbbbbbbbd...",
    "..dbbbbbbbbbbd..",
    ".lbbbbbbbbbbbbl.",
    ".dbbbbbbbbbbbbd.",
    "..dd......dd....",
    "..ttt....ttt....",
    "..tkt....tkt....",
    "..ttt....ttt....",
    "................",
    "................",
  ],
  sedan: [
    "................",
    "................",
    "................",
    "....dbbbbbbd....",
    "...dbwwbbwwbd...",
    "..dbbbbbbbbbbd..",
    ".dbbbbbbbbbbbbd.",
    ".lbbbbbbbbbbbbl.",
    ".dbbbbbbbbbbbbd.",
    ".dd..........dd.",
    "..ttt......ttt..",
    "..tkt......tkt..",
    "..ttt......ttt..",
    "................",
    "................",
    "................",
  ],
  truck: [
    "................",
    "................",
    "...dbbbd........",
    "..dbwwwbddddddd.",
    "..dbbbbbd.....d.",
    ".dbbbbbbbd....d.",
    ".lbbbbbbbbbbbbl.",
    ".dbbbbbbbbbbbbd.",
    ".dbbbbbbbbbbbbd.",
    ".dd..........dd.",
    "..ttt......ttt..",
    "..tkt......tkt..",
    "..ttt......ttt..",
    "................",
    "................",
    "................",
  ],
  van: [
    "................",
    "................",
    "..dbbbbbbbbbbd..",
    "..dbwwbbbbbbbd..",
    "..dbbbbbbbbbbd..",
    "..dbbbbbbbbbbd..",
    ".lbbbbbbbbbbbbl.",
    ".dbbbbbbbbbbbbd.",
    ".dbbbbbbbbbbbbd.",
    ".dd..........dd.",
    "..ttt......ttt..",
    "..tkt......tkt..",
    "..ttt......ttt..",
    "................",
    "................",
    "................",
  ],
  super: [
    "................",
    "................",
    "................",
    "................",
    "................",
    "......dbbbbd....",
    "....dbwwwwbbd...",
    "..dbbbbbbbbbbbd.",
    ".lbbbbbbbbbbbbl.",
    ".dbbbbbbbbbbbbd.",
    "..dd........dd..",
    "..ttt......ttt..",
    "..tkt......tkt..",
    "..ttt......ttt..",
    "................",
    "................",
  ],
};

export type CarSpriteState = {
  shape: Shape;
  color: string;
  body: boolean | number;
  wheels: boolean | number;
  paint: boolean | number;
  engine: boolean | number;
};

export function CarSprite({
  state,
  scale = 6,
  className = "",
}: {
  state: CarSpriteState;
  scale?: number;
  className?: string;
}) {
  const rows = SHAPES[state.shape] ?? SHAPES.coupe;
  const base = state.paint
    ? (SPRITE_PALETTE[state.color] ?? SPRITE_PALETTE['dull']!)
    : state.body
      ? SPRITE_PALETTE['dull']!
      : SPRITE_PALETTE['rust']!;
  const dark = shade(base);
  const px: string[] = [];

  rows.forEach((row, y) => {
    row.split("").forEach((ch, x) => {
      let color = "transparent";
      if (ch === "b") {
        // Missing body panels leave holes in the shell.
        color = !state.body && (x + y) % 3 === 0 ? "transparent" : base;
      } else if (ch === "d") color = dark;
      else if (ch === "w") color = state.body ? "#9fe8ff" : "#4a4f63";
      else if (ch === "l") color = state.engine ? "#fff3a8" : dark;
      else if (ch === "t") color = state.wheels ? "#22242e" : "#3a3030";
      else if (ch === "k") color = state.wheels ? "#d8dde8" : "#5a4a3a";
      if (color !== "transparent") px.push(`${x * scale}px ${y * scale}px 0 0 ${color}`);
    });
  });

  return (
    <div
      className={className}
      style={{
        width: 16 * scale,
        height: 16 * scale,
        position: "relative",
      }}
      aria-hidden
    >
      <div
        style={{
          position: "absolute",
          width: scale,
          height: scale,
          boxShadow: px.join(","),
        }}
      />
    </div>
  );
}

const PLAYER: string[] = [
  "................",
  "................",
  ".....hhhhhh.....",
  "....hhhhhhhh....",
  "....hssssssh....",
  "....ss.ss.ss....",
  "....ssssssss....",
  "...jjjjjjjjjj...",
  "..sjjjjjjjjjjs..",
  "..sjjjjjjjjjjs..",
  "...jjjjjjjjjj...",
  "....pppppppp....",
  "....pppppppp....",
  "....pp....pp....",
  "...bbb....bbb...",
  "................",
];

const PLAYER_COLORS: Record<string, string> = {
  h: "#3a2a1c",
  s: "#e8b48c",
  j: "#f0a93c",
  p: "#3c4a7c",
  b: "#22242e",
};

export type Outfit = { shirt?: string; pants?: string; hair?: string };

export function PlayerSprite({
  scale = 3,
  step = 0,
  outfit,
}: {
  scale?: number;
  step?: number;
  outfit?: Outfit | undefined;
}) {
  const colors: Record<string, string | undefined> = {
    ...PLAYER_COLORS,
    ...(outfit?.shirt ? { j: outfit.shirt } : {}),
    ...(outfit?.pants ? { p: outfit.pants } : {}),
    ...(outfit?.hair ? { h: outfit.hair } : {}),
  };
  const px: string[] = [];
  PLAYER.forEach((row, y) => {
    row.split("").forEach((ch, x) => {
      const c = colors[ch];
      if (!c) return;
      // simple walk cycle: shift the legs one pixel
      const xx = y >= 13 && step === 1 ? x + (x < 8 ? -1 : 1) : x;
      px.push(`${xx * scale}px ${y * scale}px 0 0 ${c}`);
    });
  });
  return (
    <div style={{ width: 16 * scale, height: 16 * scale, position: "relative" }} aria-hidden>
      <div style={{ position: "absolute", width: scale, height: scale, boxShadow: px.join(",") }} />
    </div>
  );
}
