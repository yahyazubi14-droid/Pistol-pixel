import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "ar";

const AR: Record<string, string> = {
  "LOG IN": "تسجيل الدخول",
  "START GAME": "ابدأ اللعبة",
  CUSTOMIZE: "تخصيص الشخصية",
  SETTINGS: "الإعدادات",
  "SIGN OUT": "تسجيل الخروج",
  BACK: "رجوع",
  SAVE: "حفظ",
  SAVED: "تم الحفظ",
  LANGUAGE: "اللغة",
  SHIRT: "القميص",
  PANTS: "البنطال",
  HAIR: "الشعر",
  "WRECK TO RICHES — CAR DEALERSHIP & MECHANIC SIM": "من الخردة إلى الثراء — محاكي معرض وميكانيكي سيارات",
  "WELCOME BACK": "أهلاً بعودتك",
  CASH: "النقود",
  CARS: "السيارات",
  NET: "الثروة",
  "AUCTION DAY": "يوم المزاد",
  "NEXT SUNDAY": "الأحد القادم",
  EXIT: "خروج",
  WEEK: "الأسبوع",
  "ARROWS / WASD TO WALK · SPACE TO INTERACT": "الأسهم / WASD للمشي · المسافة للتفاعل",
  "WORKSHOP — REPAIR BAY": "الورشة — منطقة الإصلاح",
  CONDITION: "الحالة",
  VALUE: "القيمة",
  "MOVE TO SHOWROOM LOT": "انقل إلى المعرض",
  LEVEL: "المستوى",
  UPGRADE: "ترقية",
  "MAX LEVEL": "أعلى مستوى",
  ENGINE: "المحرك",
  "BODY PANELS": "هيكل السيارة",
  "NEW WHEELS": "العجلات",
  "PAINT JOB": "الطلاء",
  "GARAGE EMPTY. TELEPORT TO THE SCRAP MARKET AND BUY A PROJECT CAR.":
    "المرآب فارغ. انتقل إلى سوق الخردة واشترِ سيارة.",
  "HOME GARAGE": "المرآب",
  "SCRAP MARKET": "سوق الخردة",
  SHOWROOM: "المعرض",
  "AUCTION HOUSE": "دار المزاد",
  LEADERBOARD: "لوحة المتصدرين",
};

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (s: string) => string };
const LangCtx = createContext<Ctx>({ lang: "en", setLang: () => {}, t: (s) => s });

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  useEffect(() => {
    const saved = localStorage.getItem("pp-lang");
    if (saved === "ar" || saved === "en") setLangState(saved);
  }, []);
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);
  const setLang = (l: Lang) => {
    localStorage.setItem("pp-lang", l);
    setLangState(l);
  };
  const t = (s: string) => (lang === "ar" ? (AR[s] ?? s) : s);
  return <LangCtx.Provider value={{ lang, setLang, t }}>{children}</LangCtx.Provider>;
}

export const useT = () => useContext(LangCtx);
